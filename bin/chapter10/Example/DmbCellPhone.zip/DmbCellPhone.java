package chapter10.Example;

public class DmbCellPhone extends CellPhone{
	private String channel;
	
	public void turnOnDmb (String a) {	
		channel = a;
		System.out.println("채널 " + channel + "번 DMB 방송 수신을 시작합니다");
	}

	public void turnOffDmb () {
		System.out.println("DMB 방송 수신을 멈춥니다");
	}
	
	public void changeChannelDmb (String a) {
		channel = a;
		System.out.println("채널 " + channel + "번으로 바꿉니다");
	}
	
	//-------------------------------
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	public String getChannel() {
		return channel;
	}
	//-------------------------------	



	
	
}
