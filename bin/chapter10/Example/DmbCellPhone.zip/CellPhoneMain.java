package chapter10.Example;

public class CellPhoneMain {

	public static void main(String[] args) {
		
		CellPhone cell = new CellPhone();
		DmbCellPhone dmb = new DmbCellPhone();
		
		cell.powerOn("java폰", "검정");
		dmb.bell();
		
		cell.sendVoice();
		cell.receiveVoice();
		cell.sendVoice();
		
		cell.hangUp();
		dmb.turnOnDmb("10");
		dmb.changeChannelDmb("5");
		dmb.turnOffDmb();
		cell.powerOff();

	}

}
