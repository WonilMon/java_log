package chapter10.Example;

import java.util.Scanner;

public class CellPhone {

	private String model;
	private String color;
	Scanner scan = new Scanner(System.in);
	
	public void powerOn (String a, String b) {
		DmbCellPhone d = new DmbCellPhone();
		model = a;
		color = b;
		d.setChannel("10");
		System.out.println("모델 : " + model);
		System.out.println("색상 : " + color);
		System.out.println("채널 : " + d.getChannel());
		System.out.println("전원을 켭니다");
	}
	public void powerOff () {
		System.out.println("전원을 끕니다");
		
	}
	public void bell () {
		System.out.println("벨이 울립니다");
		
	}
	
	public void sendVoice () {
		System.out.print("자기자신 : ");
		String send = scan.nextLine();		
	}
	
	public void receiveVoice () {
		System.out.print("상대방 : ");
		String send = scan.nextLine();
	}
	
	public void hangUp () {
		System.out.println("전원을 끕니다");
	}
	
}
