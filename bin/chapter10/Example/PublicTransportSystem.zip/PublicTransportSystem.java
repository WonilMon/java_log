package chapter10.Example;

import java.util.Scanner;

public class PublicTransportSystem {
	
	Scanner scan = new Scanner(System.in);
	Bus bus;
	Subway subway;
	Customer [] customer;
	int count;
	
	public PublicTransportSystem () {
		bus = new Bus();
		subway = new Subway();
		System.out.print("승객의 수를 등록하세요 >> ");
		count = Integer.parseInt(scan.nextLine());
		customer = new Customer[count];	
		for(int i=0; i<customer.length;i++) {
				customer[i] = new Customer();
			}
	}
	
	public void operate() {
		
		while (true) {
			
			System.out.print("1.승객등록 | 2.대중교통 이용 | 3.승객정보 | 4.대중교통 정보 | 5.종료 >> ");
			int num = Integer.parseInt(scan.nextLine());
			
			if(num==1) {
				
				for (int i = 0 ; i < customer.length ; i++) {
					System.out.print("승객의 이름을 등록하세요 : ");
						customer[i].setName(scan.nextLine());
					System.out.print("승객의 소지금을 등록하세요 : ");
						customer[i].setMoney(Integer.parseInt(scan.nextLine()));
					System.out.println("----------------------------------------");
				}//for
				
			}else if(num==2) {
				
				System.out.print("승객의 이름을 검색하시오 : ");
				String name = scan.nextLine();
				int c = 0;
				
				for(int i = 0 ; i < customer.length; i++) {
					if (customer[i].getName().equals(name)) {
						System.out.print("버스는 1번, 지하철은 2번을 선택하세요 >> ");
						int choice = Integer.parseInt(scan.nextLine());
						if (choice == 1) {
							customer[i].ride(bus);
						}else if (choice == 2) {
							customer[i].ride(subway);
						}
					}else if ((!(customer[i].getName().equals(name)))) {
						c++;
					}
					
					if(c==customer.length) {
						System.out.println("잘못선택하셨습니다");
					}
					
					}
				
			}else if(num==3) {
			
				System.out.print("승객의 이름을 검색하시오 >> ");
				String name = scan.nextLine();
				int c = 0;
				
				for(int i = 0 ; i < customer.length ; i++) {
					if (customer[i].getName().equals(name)) {
						customer[i].disp();
					}else if ((!(customer[i].getName().equals(name)))) {
						c++;
					}
					
					if(c==customer.length) {
						System.out.println("잘못선택하셨습니다");
					}
					
					}
			}else if(num==4) {
				System.out.print("버스는 1번 지하철은 2번을 선택하세요 >> ");
				int choice = Integer.parseInt(scan.nextLine());
				if (choice==1) {
					bus.disp();
				}else if (choice==2) {
					subway.disp();
				}else {
					System.out.println("잘못 선택하셨습니다");
				}
			
			}else if(num==5) {
				System.out.println("프로그램 종료");
				break;
			}else {
				System.out.println("1~5까지의 수만 선택해주세요");
			}
			
		}//while
	}
}

//--------------------------------------------------------
//--------------------------------------------------------

class Customer {
	
	String name = "";
	int money;
	
	public void ride(PublicTransport pt) {
		if(money >= pt.fare) {
			pt.take();
			money -= pt.fare;
			System.out.println(name + "님의 남은 소지금은 " + money + "원 입니다");
		}else {
			System.out.println(name + "님의 소지금이 부족합니다");
		}		
	}//ride
	
	public void disp () {
		System.out.println(name + "님의 소지금은 " + money + "원 입니다");
	}

	//-----------------------------------------------------------------
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}
	//-----------------------------------------------------------------
	
}

//--------------------------------------------------------
//--------------------------------------------------------

class PublicTransport { //부모클래스
	
	int fare; //요금
	int count; //승객
	int money; //수익
	
	public PublicTransport(int fare) {
		this.fare = fare;
	}
	
	public void take() {
		count++;
		money+=fare;
	}
	
	public void disp () {
		System.out.println("이용고객 수 : " + count + " | 수익 : " + money);
	}
	
	
}

//--------------------------------------------------------
//--------------------------------------------------------

class Bus extends PublicTransport{
	
	public Bus() {
		super(2000);
	}
	
	@Override
	public void take() {
		//count++;
		//money+=fare;
		super.take();
		System.out.println("버스를 이용합니다");
	}
	
	@Override
	public void disp() {
		System.out.print("버스의 ");
		super.disp();
	}
	
}

//--------------------------------------------------------
//--------------------------------------------------------

class Subway extends PublicTransport{
	
	public Subway() {
		super(1500);
	}
	
	@Override
	public void take() {
		//count++;
		//money+=fare;
		super.take();
		System.out.println("지하철을 이용합니다");
	}
	
	@Override
	public void disp() {
		System.out.print("지하철의 ");
		super.disp();
	}
	
}






