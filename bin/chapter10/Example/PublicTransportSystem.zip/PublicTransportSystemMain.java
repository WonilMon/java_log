package chapter10.Example;

public class PublicTransportSystemMain {

	public static void main(String[] args) {
	
		PublicTransportSystem ps = new PublicTransportSystem ();
		ps.operate();
		
	}

}

