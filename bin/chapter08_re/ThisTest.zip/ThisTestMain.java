package chapter08_re;

import javax.swing.JOptionPane;

public class ThisTestMain {

	public static void main(String[] args) {
		
		ThisTest r1 = new ThisTest();
		
		r1.setSpeed(Integer.parseInt(JOptionPane.showInputDialog("로봇 속도")));
		r1.setAge(Integer.parseInt(JOptionPane.showInputDialog("로봇 나이")));
		r1.setRobotName(JOptionPane.showInputDialog("로봇 이름"));
		r1.setRobotNum(JOptionPane.showInputDialog("로봇 번호"));
		
		System.out.println("속도 : " + r1.getSpeed());
		System.out.println("나이 : " + r1.getAge());
		System.out.println("이름 : " + r1.getRobotName());
		System.out.println("번호 : " + r1.getRobotNum());
		
		System.out.println("----------------------------");
		
		r1.move(); //속도 20+
		r1.rName(); //생성자 주입 이름
		r1.rAge(); //생성자 주입 나이
		r1.move();
		r1.move();
		r1.move();
		r1.stop(); //속도값 0
		
		

	}

}
