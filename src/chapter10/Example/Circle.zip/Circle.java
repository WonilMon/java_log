package chapter10.Example;

public class Circle extends Shape{

	@Override
	public void draw() {
		System.out.println("원을 그립니다");
	}
	
}
