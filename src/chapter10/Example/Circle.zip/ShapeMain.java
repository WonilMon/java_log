package chapter10.Example;

public class ShapeMain {

	public static void main(String[] args) {

		Shape s = new Shape();
		Circle c = new Circle();
		Square q = new Square();
		
		s.draw();
		c.draw();
		q.draw();

	}

}
