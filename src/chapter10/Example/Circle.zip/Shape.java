package chapter10.Example;

public class Shape {
	
	public void draw () {
		
		System.out.println("그림을 그립니다");
		
	}

}
