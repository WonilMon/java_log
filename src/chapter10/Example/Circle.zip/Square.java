package chapter10.Example;

public class Square extends Shape{

	@Override
	public void draw() {
		System.out.println("네모를 그립니다");
	}

	
	
}
