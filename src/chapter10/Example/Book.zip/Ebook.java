package chapter10.Example;

public class Ebook extends Book{
	
	int day;
	
	public void title (int a) {
		super.title("앵무새 죽이기", "하퍼 리");
		day = a;
	}
	
	public void disp() {
		super.disp();
		System.out.println("대여기간 " + day + "일");
	}
	
}
