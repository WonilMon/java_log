package chapter10.Example;

public class BookMain {

	public static void main(String[] args) {
		
		Ebook e = new Ebook();
		e.title(30);
		e.disp();

	}

}
