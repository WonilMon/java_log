package chapter10.Example;

public class Book {
	
	private String title;
	private String author;
	
	public void title (String a, String b) {
		title = a;
		author = b;
	}
	
	public void disp() {
		System.out.println("Title : " + title);
		System.out.println("Author : " + author);
	}
	
	
}
