package chapter09;

import java.util.Scanner;

public class Guide {

	static String point;
	Guest[] guest;
	Scanner scan = new Scanner(System.in);
	
	public Guide() {}
	
	public Guide(int n) {
		
		System.out.println("관광객 등록");
		guest = new Guest [n];
		for(int i = 0 ; i<guest.length;i++) {
			System.out.print((i+1) + ". 이름 : ");
			String name = scan.nextLine();
			System.out.print((i+1) + ". 성별 : ");
			String gender = scan.nextLine();
			guest[i] = new Guest(name,gender);
			point = "가거도";
			System.out.println("--------------");
		}
	}//생성자
	
	public void choice () {
		while(true) {
			
		System.out.println("1. 관광객 정보");
		System.out.println("2. 목적지 변경");
		System.out.println("3. 종료");
		System.out.print("선택 >> ");
		int num =Integer.parseInt(scan.nextLine());
		if (num==1) {
			for(int i =0 ; i<guest.length;i++) {
				System.out.println((i+1) + ". 이름 : " +guest[i].getName());	
				System.out.println((i+1) + ". 성별 : " +guest[i].getGender());	
				System.out.println((i+1) + ". 목적지 : " + point);	
			}
			
		}else if(num==2) { 
			System.out.print("어디로 변경하시겠습니까 : ");
			String change = scan.nextLine();
			point = change;
		}else if(num==3) {
			System.out.println("프로그램을 종료합니다");
			break;
		}else {
			System.out.println("1~3까지의 숫자만 선택해주세요");
		}
		System.out.println("---------------------------");
		}
		
	}
	
	
}
