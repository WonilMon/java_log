package chapter09;

import java.util.Scanner;

public class Tour {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		
		System.out.print("관광객 수 : ");
		Guide g = new Guide(Integer.parseInt(scan.nextLine()));
		g.choice();
		
		
	}//main
	
}//class
