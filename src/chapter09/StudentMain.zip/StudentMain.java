package chapter09;

public class StudentMain {

	public static void main(String[] args) {
		
		Student studentLee = new Student("이예찬", 3);
		
		Student studentKim = new Student("김하경", 2);
		
		Student studentYim = new Student("임승연", 1);
		
		studentYim.print();
		studentKim.print();
		studentLee.print();
		
		
	}

}
