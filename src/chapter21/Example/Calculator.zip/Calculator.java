package chapter21.Example;

@FunctionalInterface
public interface Calculator {
	
	int calculate(int num1, int num2);
	
}
