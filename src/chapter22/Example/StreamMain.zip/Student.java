package chapter22.Example;

public class Student {
	
	private int num = 1000;
	private String name;
	private String department;
	private int stdNum;
	private int age;
	

	
	public Student (int num, String name,String department,int stdNum,int age) {
		this.num += num;
		this.name = name;
		this.department = department;
		this.stdNum = stdNum;
		this.age = age;
	}

	@Override
	public String toString() {
		return num + "\t" + department + "\t" + stdNum + "학년" + "\t" + name + "\t" + "나이 : " + age;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getStdNum() {
		return stdNum;
	}

	public void setStdNum(int stdNum) {
		this.stdNum = stdNum;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
}
