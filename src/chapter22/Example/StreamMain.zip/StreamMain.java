package chapter22.Example;

public class StreamMain {

	public static void main(String[] args) {
		
		StreamTest st = new StreamTest();
		st.run();
		
		
	}

}
