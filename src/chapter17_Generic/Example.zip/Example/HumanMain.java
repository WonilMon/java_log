package chapter17_Generic.Example;

public class HumanMain {

	public static void main(String[] args) {
		
		HumanGeneric<Student> student = new HumanGeneric<Student>();
		student.setHuman(new Student("김씨", "20", "1"));
		student.act();
		System.out.println(student.getHuman());
		
		System.out.println("--------------------------");
		
		HumanGeneric<Professor> professor = new HumanGeneric<Professor>();
		professor.setHuman(new Professor("이씨", "45", "컴퓨터공학과"));
		professor.act();
		System.out.println(professor.getHuman());
		
		

	}

}
