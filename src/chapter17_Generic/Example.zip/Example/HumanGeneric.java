package chapter17_Generic.Example;

public class HumanGeneric <T extends Human> {
	
	T human;
	
	public void act() {
		human.act();
	}
	
	//-------------------------------
	public T getHuman() {
		return human;
	}

	public void setHuman(T human) {
		this.human = human;
	}
	//-------------------------------
	
}
